import { Palestrante } from './palestrante';

export const PALESTRANTES: Palestrante[] = [
    { nome: 'Nome do palestrante1', horario: '7:00', tema: 'tema palestra' },
    { nome: 'Nome do palestrante2', horario: '7:30', tema: 'tema palestra' },
    { nome: 'Nome do palestrante3', horario: '8:00', tema: 'tema palestra' },
    { nome: 'Nome do palestrante4', horario: '8:30', tema: 'tema palestra' },
    { nome: 'CofeeBreak', horario: '9:00', tema: '--' }
];
