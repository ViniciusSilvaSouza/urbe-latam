export class Palestrante {
    nome: string;
    horario: string;
    tema: string;
}